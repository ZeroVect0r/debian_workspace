//meassage display
#include <iostream>
int main() {
    using namespace std;

    cout << "[*]this is the first program";
    cout << endl;
    cout << "[*]hello, world!" << endl;
    
    cin.get();

    return 0;
}